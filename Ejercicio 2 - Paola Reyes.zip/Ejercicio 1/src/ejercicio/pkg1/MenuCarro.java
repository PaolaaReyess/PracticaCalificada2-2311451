/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejercicio.pkg1;

/**
 *
 * @author lucib
 */

// Clase MenuCarro
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;

public class MenuCarro extends JFrame implements ActionListener {
  // Componentes de la interfaz
  private JDesktopPane desktop;
  private JMenuBar menuBar;
  private JMenu menu;
  private JMenuItem itemRegistrar, itemListar, itemSalir;

  // Lista de carros registrados
  ArrayList<Carro> carros;

  // Constructor
  public MenuCarro() {
    // Inicializar la lista de carros
    carros = new ArrayList<>();

    // Configurar la ventana
    setTitle("Menu Carro");
    setSize(600, 400);
    setLocationRelativeTo(null);
    setDefaultCloseOperation(EXIT_ON_CLOSE);

    // Crear el panel de escritorio
    desktop = new JDesktopPane();

    // Crear la barra de menú
    menuBar = new JMenuBar();

    // Crear el menú
    menu = new JMenu("Opciones");

    // Crear los ítems del menú
    itemRegistrar = new JMenuItem("Registrar Carro");
    itemListar = new JMenuItem("Listar Carros");
    itemSalir = new JMenuItem("Salir");

    // Añadir los ítems al menú
    menu.add(itemRegistrar);
    menu.add(itemListar);
    menu.add(itemSalir);

    // Añadir el menú a la barra de menú
    menuBar.add(menu);

    // Añadir la barra de menú a la ventana
    setJMenuBar(menuBar);

    // Añadir el panel de escritorio a la ventana
    add(desktop);

    // Añadir los escuchadores de eventos a los ítems del menú
    itemRegistrar.addActionListener(this);
    itemListar.addActionListener(this);
    itemSalir.addActionListener(this);

    // Hacer visible la ventana
    setVisible(true);
  }

  // Método para manejar los eventos de los ítems del menú
  public void actionPerformed(ActionEvent e) {
    // Si se selecciona el ítem Registrar Carro
    if (e.getSource() == itemRegistrar) {
      // Crear una instancia de la clase InterfazCarro
      InterfazCarro ic = new InterfazCarro();

      // Añadir el formulario al panel de escritorio
      desktop.add(ic);

      // Mostrar el formulario
      ic.show();
    }

    // Si se selecciona el ítem Listar Carros
    if (e.getSource() == itemListar) {
      // Crear una instancia de la clase ListarCarros
      ListarCarros lc = new ListarCarros(carros);

      // Añadir el formulario al panel de escritorio
      desktop.add(lc);

      // Mostrar el formulario
      lc.show();
    }

    // Si se selecciona el ítem Salir
    if (e.getSource() == itemSalir) {
      // Terminar el programa
      System.exit(0);
    }
  }

  // Método principal
  public static void main(String[] args) {
    // Crear una instancia de la clase MenuCarro
    new MenuCarro();
  }
}
