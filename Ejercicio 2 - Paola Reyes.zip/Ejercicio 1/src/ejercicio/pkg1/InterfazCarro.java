/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejercicio.pkg1;

/**
 *
 * @author lucib
 */
// Clase InterfazCarro
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class InterfazCarro extends JInternalFrame implements ActionListener {
  // Componentes de la interfaz
  private JLabel lblModelo, lblColor, lblPintura, lblPlaca, lblTipo, lblAño, lblSeguro;
  private JTextField txtModelo, txtColor, txtPlaca, txtAño;
  private JCheckBox chkPintura;
  private JComboBox<TipoCarro> cmbTipo;
  private JRadioButton rdbTerceros, rdbTodoRiesgo;
  private ButtonGroup bgSeguro;
  private JButton btnGuardar, btnCancelar;

  // Objeto carro
  private Carro carro;

  // Referencia al menú principal
  private MenuCarro menu;

  // Constructor
  public InterfazCarro() {
    // Inicializar el objeto carro con valores por defecto
    carro = new Carro("Toyota", "Rojo", false, "ABC-123", TipoCarro.UTILITARIO, 2020, ModalidadSeguro.TERCEROS);

    // Obtener la referencia al menú principal
    menu = (MenuCarro) getDesktopPane().getTopLevelAncestor();

    // Configurar el formulario interno
    setTitle("Registrar Carro");
    setClosable(true);
    setMaximizable(true);
    setIconifiable(true);
    setResizable(true);
    setSize(400, 300);
    setLocation(100, 100);
    setLayout(new GridLayout(8, 2, 5, 5));

    // Crear los componentes de la interfaz
    lblModelo = new JLabel("Modelo:");
    txtModelo = new JTextField(carro.getModelo());
    lblColor = new JLabel("Color:");
    txtColor = new JTextField(carro.getColor());
    lblPintura = new JLabel("Pintura metalizada:");
    chkPintura = new JCheckBox();
    chkPintura.setSelected(carro.isPinturaMetalizada());
    lblPlaca = new JLabel("Placa:");
    txtPlaca = new JTextField(carro.getPlaca());
    lblTipo = new JLabel("Tipo de carro:");
    cmbTipo = new JComboBox<>(TipoCarro.values());
    cmbTipo.setSelectedItem(carro.getTipo());
    lblAño = new JLabel("Año de fabricación:");
    txtAño = new JTextField(String.valueOf(carro.getAñoFabricacion()));
    lblSeguro = new JLabel("Modalidad de seguro:");
    rdbTerceros = new JRadioButton("A terceros");
    rdbTodoRiesgo = new JRadioButton("A todo riesgo");
    bgSeguro = new ButtonGroup();
    bgSeguro.add(rdbTerceros);
    bgSeguro.add(rdbTodoRiesgo);
    if (carro.getSeguro() == ModalidadSeguro.TERCEROS) {
      rdbTerceros.setSelected(true);
    } else {
      rdbTodoRiesgo.setSelected(true);
    }
    btnGuardar = new JButton("Guardar");
    btnCancelar = new JButton("Cancelar");

    // Añadir los componentes al formulario interno
    add(lblModelo);
    add(txtModelo);
    add(lblColor);
    add(txtColor);
    add(lblPintura);
    add(chkPintura);
    add(lblPlaca);
    add(txtPlaca);
    add(lblTipo);
    add(cmbTipo);
    add(lblAño);
    add(txtAño);
    add(lblSeguro);
    add(new JLabel()); // Espacio en blanco
    add(rdbTerceros);
    add(rdbTodoRiesgo);
    add(btnGuardar);
    add(btnCancelar);

    // Añadir los escuchadores de eventos a los botones
    btnGuardar.addActionListener(this);
    btnCancelar.addActionListener(this);
  }

  // Método para manejar los eventos de los botones
  @Override
  public void actionPerformed(ActionEvent e) {
    // Si se presiona el botón guardar
    if (e.getSource() == btnGuardar) {
      // Obtener los datos de la interfaz y asignarlos al objeto carro
      carro.setModelo(txtModelo.getText());
      carro.setColor(txtColor.getText());
      carro.setPinturaMetalizada(chkPintura.isSelected());
      carro.setPlaca(txtPlaca.getText());
      carro.setTipo((TipoCarro) cmbTipo.getSelectedItem());
      carro.setAñoFabricacion(Integer.parseInt(txtAño.getText()));
      if (rdbTerceros.isSelected()) {
        carro.setSeguro(ModalidadSeguro.TERCEROS);
      } else {
        carro.setSeguro(ModalidadSeguro.TODO_RIESGO);
      }
      // Añadir el objeto carro a la lista del menú principal
      menu.carros.add(carro);

      // Mostrar un mensaje de confirmación
      JOptionPane.showMessageDialog(this, "El carro se ha registrado correctamente.");

      // Cerrar el formulario interno
      dispose();
    }
    // Si se presiona el botón cancelar
    if (e.getSource() == btnCancelar) {
      // Cerrar el formulario interno
      dispose();
    }
  }
}
