package ejercicio.pkg1;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author lucib
 */
public class Carro {
  
    public static final String[] TIPOS = {"MINI", "UTILITARIO", "FAMILIAR", "DEPORTIVO"};
   
    public static final String[] SEGUROS = {"A TERCEROS", "A TODO RIESGO"};
    
    private String modelo;
    private String color;
    private boolean pinturaMetalizada;
    private String placa;
    private String tipo;
    private int año;
    private String seguro;
    
   
    public Carro(String modelo, String color, boolean pinturaMetalizada, String placa, String tipo, int año, String seguro) {
        this.modelo = modelo;
        this.color = color;
        this.pinturaMetalizada = pinturaMetalizada;
        this.placa = placa;
        this.tipo = tipo;
        this.año = año;
        this.seguro = seguro;
    }
   
    public String getModelo() {
        return modelo;
    }
    
    public void setModelo(String modelo) {
        this.modelo = modelo;
    }
    
    public String getColor() {
        return color;
    }
    
    public void setColor(String color) {
        this.color = color;
    }
    
    public boolean isPinturaMetalizada() {
        return pinturaMetalizada;
    }
    
    public void setPinturaMetalizada(boolean pinturaMetalizada) {
        this.pinturaMetalizada = pinturaMetalizada;
    }
    
    public String getPlaca() {
        return placa;
    }
    
    public void setPlaca(String placa) {
        this.placa = placa;
    }
    
    public String getTipo() {
        return tipo;
    }
    
    public void setTipo(String tipo) {
        this.tipo = tipo;
    }
    
    public int getAño() {
        return año;
    }
    
    public void setAño(int año) {
        this.año = año;
    }
    
    public String getSeguro() {
        return seguro;
    }
    
    public void setSeguro(String seguro) {
        this.seguro = seguro;
    }
    
    @Override
    public String toString() {
        return "Modelo: " + modelo + "\n" +
               "Color: " + color + "\n" +
               "Pintura metalizada: " + (pinturaMetalizada ? "Sí" : "No") + "\n" +
               "Placa: " + placa + "\n" +
               "Tipo: " + tipo + "\n" +
               "Año: " + año + "\n" +
               "Seguro: " + seguro + "\n";
    }
}
